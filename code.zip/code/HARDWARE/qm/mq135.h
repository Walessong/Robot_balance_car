#ifndef __MQ135_H
#define	__MQ135_H
#include "stm32f10x.h"
#include "adcx.h"
#include "delay.h"
#include "math.h"


#define MQ135_READ_TIMES	10  

#define	MODE 	1

#if MODE
#define		MQ135_AO_GPIO_CLK								RCC_APB2Periph_GPIOA
#define 	MQ135_AO_GPIO_PORT							GPIOA
#define 	MQ135_AO_GPIO_PIN								GPIO_Pin_4
#define   ADC_CHANNEL               			ADC_Channel_4	

#else
#define		MQ135_DO_GPIO_CLK								RCC_APB2Periph_GPIOA
#define 	MQ135_DO_GPIO_PORT							GPIOA
#define 	MQ135_DO_GPIO_PIN								GPIO_Pin_4		

#endif
/*********************END**********************/


void MQ135_Init(void);
uint16_t MQ135_GetData(void);
float MQ135_GetData_PPM(void);

#endif /* __ADC_H */

